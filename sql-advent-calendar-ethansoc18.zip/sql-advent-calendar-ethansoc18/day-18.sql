-- SQL Advent Calendar - Day 18
-- Title: 12 Days of Data - Progress Tracking
-- Difficulty: hard
--
-- Question:
-- Over the 12 days of her data challenge, Data Dawn tracked her daily quiz scores across different subjects. Can you find each subject's first and last recorded score to see how much she improved?
--
-- Over the 12 days of her data challenge, Data Dawn tracked her daily quiz scores across different subjects. Can you find each subject's first and last recorded score to see how much she improved?
--

-- Table Schema:
-- Table: daily_quiz_scores
--   subject: VARCHAR
--   quiz_date: DATE
--   score: INTEGER
--

-- My Solution:

SELECT 
    subject,
    MAX(CASE WHEN quiz_date = (SELECT MIN(quiz_date) FROM daily_quiz_scores dqs2 WHERE dqs2.subject = dqs1.subject) 
             THEN score END) AS first_score,
    MAX(CASE WHEN quiz_date = (SELECT MAX(quiz_date) FROM daily_quiz_scores dqs2 WHERE dqs2.subject = dqs1.subject) 
             THEN score END) AS last_score
FROM daily_quiz_scores dqs1
GROUP BY subject;
